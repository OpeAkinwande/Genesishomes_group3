import React, { useState } from 'react';
import { Home, Search, ShoppingCart, User, ChevronDown } from 'lucide-react';

// Mock data for real estate listings
const realEstateListings = Array.from({ length: 24 }, (_, i) => ({
  id: i + 1,
  name: `Beautiful Property ${i + 1}`,
  price: Math.floor(Math.random() * 900000) + 100000,
  image: `https://source.unsplash.com/800x600/?house&sig=${i}`
}));

function App() {
  const [isShopMenuOpen, setIsShopMenuOpen] = useState(false);
  const [cart, setCart] = useState<number[]>([]);

  const addToCart = (id: number) => {
    setCart([...cart, id]);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Bar */}
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <a href="/" className="flex items-center space-x-2">
                <Home className="h-6 w-6 text-purple-600" />
                <span className="font-bold text-xl">DreamHome</span>
              </a>
              
              <div className="relative">
                <button 
                  onClick={() => setIsShopMenuOpen(!isShopMenuOpen)}
                  className="flex items-center space-x-1 hover:text-purple-600"
                >
                  <span>Shops</span>
                  <ChevronDown className="h-4 w-4" />
                </button>
                
                {isShopMenuOpen && (
                  <div className="absolute top-full left-0 w-48 bg-white shadow-lg rounded-md py-2 z-50">
                    {['Shop 1', 'Shop 2', 'Shop 3', 'Shop 4'].map((shop) => (
                      <a
                        key={shop}
                        href="#"
                        className="block px-4 py-2 hover:bg-purple-50 hover:text-purple-600"
                      >
                        {shop}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-6">
              <div className="relative flex items-center">
                <Search className="absolute left-3 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search properties..."
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:border-purple-500"
                />
              </div>
              
              <button className="flex items-center space-x-1 hover:text-purple-600">
                <User className="h-6 w-6" />
                <span>Sign Up</span>
              </button>
              
              <button className="flex items-center space-x-1 hover:text-purple-600">
                <ShoppingCart className="h-6 w-6" />
                <span className="bg-purple-600 text-white rounded-full px-2 py-1 text-xs">
                  {cart.length}
                </span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Featured Properties</h1>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {realEstateListings.map((property) => (
            <div key={property.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
              <img
                src={property.image}
                alt={property.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{property.name}</h3>
                <p className="text-gray-600 mb-4">${property.price.toLocaleString()}</p>
                <button
                  onClick={() => addToCart(property.id)}
                  className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 transition-colors"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;